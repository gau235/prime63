#include <stdio.h>

int main() {

	//bool isToRepeat=true;
	int i,qty,cost,pay,ret;
	
	int dollarAry[6]= {500,100,50,10,5,1};
	int retQtyAry[6]= {0};
	char sel;

//again:
	printf("�п�ܰӫ~: a. ���Ф� (7 ��) b. ��l�� (16 ��) c. �ߥi�� (60 ��)\n");
	scanf("%c", &sel);// bug, use char will go weird
	//printf("sel=%c\n", sel);

	printf("�п�J�R�X��?\n");
	scanf("%d", &qty);

	if(sel=='a') {

		cost=qty*7;

	} else if(sel=='b') {

		cost=qty*16;

	} else if(sel=='c') {

		cost=qty*60;

	}

	//////////////////////////////
start:
	printf("�ʶR���B:%d\n",cost);
	printf("�п�J�I�ڪ��B:\n");
	scanf("%d", &pay);

	ret = pay-cost;

	if(ret < 0) {

		goto start;

	}

	for(i=0; i<6; i++) {

		retQtyAry[i] = ret/dollarAry[i];
		ret = ret%dollarAry[i];
		printf("���B[%d]����Ӽ�=%d\n", dollarAry[i], retQtyAry[i]);

	}


	return 0;

}
