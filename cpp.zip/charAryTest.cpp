#include <stdio.h>

int main( )   {

	//char y[7]= {'d','r','a','g','o','n'};
	char y[7]= {'d','r','a','g','o','n','\0'};
	char* p;
	p=y;
 	printf("*&p=%X\n", *&p);
	p++;

	printf("&p=%X\n", &p);
	//printf("*&p=%X\n", *&p);
	printf("&y=%X\n", &y);
	
	printf("*p=%c\n", *p);
	(*p)++;

	printf("y[1]=%c\n", y[1]);
	//printf("&y[0]=%c\n", &y[0]);
	//printf("&y[1]=%c\n", &y[1]);

	printf("%X\n", &y);
	printf("&y[3]=%X\n", &y[3]);

	return 0;

}
