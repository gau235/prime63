#include <stdio.h>

int countOfRecur = 0;

int fibRecursive(int n) {

	if (n <= 1) {

		return n;

	}

	printf("ADD\n");
	countOfRecur++;

	return fibRecursive(n - 1) + fibRecursive(n - 2);

}

int main() {

	int num;
	int ans, ans2;
//	static int countOfRecur=0;

	printf("input a num:");

	scanf("%d", & num);
	printf("num=%d\n", num);

	ans2 = fibRecursive(num);

	printf("FibRecursive(%d)=%d\n", num, ans2);
	printf("countOfRecur=%d\n", countOfRecur);

	return 0;

}
