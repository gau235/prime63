#include <stdio.h>
#include <algorithm>

using namespace std;

double findMedianNAvg(int A[], int n, int* median, int* avg) {

	int sum=0;
	
	for(int i=0; i<n; i++)
		
		sum += A[i];

	*avg = (double) sum / (double) n;
	
	//int A[10]={2,4,1,23,5,76,0,43,24,65};
 	sort(A, A+n);
	
	if(n%2 == 1)
	
		*median = (double) A[n/2];	
	else 
		*median = (double) (A[(n-1)/2]+A[n/2]) / 2.0;
		
			

} 

int main() {

	int A[]={-10, 20, 30, 40};
 
 	int n = sizeof(A)/sizeof(A[0]);
 	
	 int x=0;
 	int* x1 = &x;
 	
 	int y=0;
 	int* y1 = &y;
 
 	findMedianNAvg(A, n, x1, y1);
	
	printf("median=%d\n", *x1);
	printf("avg=%d", *y1);
	
	return 0;
	
}


