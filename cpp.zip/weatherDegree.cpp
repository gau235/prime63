#include <stdio.h>
#define ROW 3
#define COL 4

int main() {

	int i,j;
	double degr[3][4]= {{18.2, 17.3, 15.0, 13.4},
		{23.8, 25.1, 20.6, 17.8},
		{20.6, 21.5, 18.4, 15.7}
	};

	for(i=0; i<ROW; i++) {

		printf("�ɬq[%d] �b�g�@��g�|��Ť��O��:", i+1 );

		for(j=0; j<COL; j++) {

			printf("%.1f\t", degr[i][j]);

		}

		printf("\n");

	}
	
	return 0;

}
