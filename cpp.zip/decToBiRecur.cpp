#include <stdio.h>

void decToBi(int n) {

	if(n!=0) {

		decToBi(n/2);
		putchar('0'+ n%2);

	}
}

int main( )   {

	decToBi(4);

	return 0;

}
