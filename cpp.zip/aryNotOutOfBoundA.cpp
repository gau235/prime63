#include <stdio.h>

void printAry(int* p, int len) {
	
	for(int i=0; i<len; i++)
		printf("%d, ",*(p+i));
		
}

void func(int* p, int len, int range) {

	int* p1;
	int* p2 = p;
	
	printf("bef=========\n");
	printf("ary=");	
	printAry(p,len);
	printf("\n");
	
	for(p1= p+len-1; p1> (p-1) ; p1--){
		
		printf("(p1+range)=%d\n", (p1+range));
		//printf("*(p1+input2)=%d\n", *(p1+input2));
		
		//printf("p1=%d\n",p1);
		//printf("*p1=%d\n",*p1);
		
		*(p1+range) = *p1;
		printf("ary=");
		printAry(p,len+2);
		printf("\n");
		
	}
	
	printf("\naft=========\n");
	for(int i= 0; i<len+3; i++)
		printf("%d, ",*(p+i));	
	
	printf("\n");
	
	for(p1= p+len; p2<p+range ; p1++){
		
		*p2++ = *p1;
		printf("ary=");	
		printAry(p,len);
		printf("\n");
		
	}
}

int main() {

	int ary[5]={103,45,99,38,76};

 	int len=5;
	int range=2;
	
	func(ary, len, range);
 
	return 0;

}
