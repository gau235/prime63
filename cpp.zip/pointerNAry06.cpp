#include <stdio.h>

int main( )   {

	char* x[3]= {"BENZ","AUDI", "HONDA"};

	printf("%d\n", &x);
	printf("%d\n", &x+1);
	//printf("%d\n", &(x+1);// err

	printf("%d\n", &x+2);

	////////////////////////

	printf("%p\n", &x);
	printf("%p\n", &x+1);

	return 0;

}
