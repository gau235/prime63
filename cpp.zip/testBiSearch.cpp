#include <stdio.h>
#define LEN 6

int main() {


	int ary[]= {2,3,5,6,8,19};
	int key=19;

	int low=0;
	int high=LEN-1;
	int time=1;

	int iFound=-1;

	while(low<=high) {

		int mid=(low+high)/2;

		if(key==ary[mid]) {

			printf("iFound=%d, time=%d\n",mid, time);
			iFound=mid;
			break;

		}


		if(key<ary[mid]) {

			high=mid-1;
			time++;

		}

		if(key>ary[mid]) {

			low=mid+1;
			time++;

		}






	}


	if(iFound==-1) {

		printf("not found\n", time);

	}
	
	return 0;

}



