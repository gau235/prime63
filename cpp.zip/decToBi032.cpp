#include <stdio.h>

void decToB32(int num) {

	int a[32];

	for(int i=31; i>=0; i--) {
	 
		a[i]=num%2;
		//a[len-i]=num%2;
		num=num/2;

		/*
		*�Ʀr *=2 // �V���� 1 ��
		*�Ʀr /=2 // �V�k�� 1 ��
		*�Ʀr %2 // ���X�Ӧ�
		*/

	}

	int iUnderline = 1;	  
	for(int i=0; i<32; i++) {

		if(iUnderline%8==0 && iUnderline<31 ) {

			printf("%d_", a[i]);

		}else{
			
			printf("%d", a[i]);
			
		}
	
		iUnderline++;

	}

	printf("\n");

}

int main( )   {

	int num;
	printf("�п�J 10 �i���\n");
	scanf("%d", &num);

	decToB32(num);

	return 0;

}
