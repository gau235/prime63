#include <stdio.h>
#include <stdlib.h>

int sumDigit(int n) {

	if(n<10) {

		return n;

	}

	return sumDigit(n/10)+sumDigit(n%10);

}

int main(){

	int num;

	printf("�п�J�Ʀr:\n");

	if(num>=99999) {

		return -1;

	}

	scanf("%d", &num);

	printf("aft sumDigit=%d\n", sumDigit(num));

}
