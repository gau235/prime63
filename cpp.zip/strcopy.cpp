#include <stdio.h>
#include <string.h>

int main( )   {

	char s1[3]= {'a','b','c'};
	strcpy(s1,"tire-bouchon");
	strcpy(&s1[4],"d-or-wi");
	strcat(s1,"red?");
	
	printf("after=%s\n", s1);
	printf("strlen=%d\n", strlen(s1));//not include char'\0'

	return 0;

}
