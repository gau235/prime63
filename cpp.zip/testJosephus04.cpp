#include <stdio.h>
#include <stdlib.h>
#define LEN 5
#define EVERY_N 3

int main() {

	int ary[LEN] = {10,20,30,40,50};

	printf("bef Josephus �ƦC:\n");
	for(int count = 0; count < LEN; count++) {

		printf("%d ", ary[count]);

	}

	printf("\n");

	int count = 1;//���Ʊq�� 1 �H�_
	int idx = 0;//�� 0 ��m
	int killed=0;//�X�C�j��

	while(killed <LEN) {

		printf("count=%d, idx=%d\n", count, idx);

		if(count==EVERY_N) {

			printf("idx=%d, to kill=%d\n", idx, ary[idx]);
			killed++;
			ary[idx]=-1;//killed
			count=0;

		}

		count++;
		idx++;
		idx=idx%LEN;

		///////////////////
		while(ary[idx]==-1) {

			idx++;
			idx=idx%LEN;

		}////////////////


	}

	return 0;

}
