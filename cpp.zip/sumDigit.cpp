#include <stdio.h>

int sumDigit(int n) {

	if(n<10) {

		return n;

	}

	int ret=0;
	while(n!=0) {

		ret+=n%10;
		n/=10;

	}

	return ret;

}

int main() {

	int num;

	printf("�п�J�Ʀr:\n");

	if(num>=99999) {

		return -1;

	}

	scanf("%d", &num);

	printf("aft sumDigit=%d\n", sumDigit(num));

}
