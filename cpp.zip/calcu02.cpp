#include <stdio.h>
#define SIZE 5

int calcu(int* k) {

	*k+=4;

	return 3 * (*k) -1;

}

int main( )   {

	int i=10, j=10;
	int ret1, ret2,ret3,ret4;

	ret1 = (i/2)+calcu(&i);
	ret2 = calcu(&j)+(j/2);

	////////////////////////////////

	i=10, j=10;
	ret3 = calcu(&i)+(i/2);
	ret4 = (j/2)+calcu(&j);

	printf("ret1=%d\n", ret1);
	printf("ret2=%d\n", ret2);
	
	printf("ret3=%d\n", ret3);
	printf("ret4=%d\n", ret4);

	return 0;

}


