#include <stdio.h>
#include <stdlib.h>

int main() {

	int* ptr;
	int i;

	ptr = (int*)malloc(3*sizeof(int));
	*ptr=12;
	*(ptr+1)=35;
	*(ptr+2)=140;

	for(i=0; i<3; i++) {

		printf("addr ptr+%d=%d\n", i, (ptr+i));//23fe4c
		printf("ptr+%d=%d\n", i, *(ptr+i));//23fe4c

	}

	free(ptr);
	printf("addr ptr=%d\n", ptr);//�ݭ�

	ptr=NULL;
	printf("addr ptr=%d\n", ptr);//0 
	
	return 0;

}


