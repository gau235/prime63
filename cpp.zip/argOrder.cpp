#include <stdio.h>

void func(int a, int b) {

	printf("a=%d\n", a);
	printf("b=%d\n", b);

}

int main() {

	int a=10;
	int b=20;
	func(a+b, ++b);

}


