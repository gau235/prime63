#include <stdio.h>

void printAry(int* p, int len) {
	
	for(int i=0; i<len; i++)
		printf("%d, ",*(p+i));
		
}

void func(int* p, int len, int range) {

	int* p1;
	int* p2 = p;
	
	for(p1= p+len-1; p1> (p-1) ; p1--){
		
		*(p1+range) = *p1;
	}
	
	for(p1= p+len; p2<p+range ; p1++){
		
		*p2++ = *p1;
	}
}

int main() {

	int ary[5]={103,45,99,38,76};

 	int len=5;
	int range=2;
	
	printf("bef ary=");	
	printAry(ary,len);
	
	func(ary, len, range);
 	
	printf("\n");
	printf("aft ary=");	
	printAry(ary,len);
 
	return 0;

}
