#include <stdio.h>

int main() {

  int num;
  printf("input a num:");

  scanf("%d", & num);
  printf("num=%d\n", num);
  
  int num2 = num;
  int i, j;
  
  for (int i = 1; i <= num; i++) {

    for (int j = 1; j <= i; j++) {

      printf("%d", i);
    
      if (--num2 == 0) {

        return 0;

      }

    }

    printf("\n");

  }

  return 0;
}
