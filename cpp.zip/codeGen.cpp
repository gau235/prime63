#include <iostream>
using namespace std;

int codeGen(int);

int main() {

	int pwd;
	char go;

	do {

		cout << "Enter password: " << endl;
		cin >> pwd ;

		if(pwd>=100 && pwd<=9999) {

			cout << codeGen(pwd) << endl;

		}

		cout << "continue?" << endl;
		cin >> go ;

	} while(go=='y'||go=='Y');

	return 0;

}

int codeGen(int pwd) {

	int backup = pwd;
	int product=1;

	while(pwd != 0) {

		product*= pwd%10;
		pwd/=10;

	}

	return backup*10 + product%10;

	/*
	*�Ʀr *=10 // �V���� 1 ��
	*�Ʀr /=10 // �V�k�� 1 ��
	*�Ʀr %10 // ���X�Ӧ�
	*/

}
