#include <stdio.h>

int func() ;

int main() {

	func();
	func();
	func();

}

int func( ) {

	static int a=100;
	printf("in func() a=%d\n", a);
	a+=200;

}
