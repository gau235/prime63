#include <stdio.h>

void input(int p) {

	scanf("%d",&p);

}

int main() {

	int num=15;

	input(num);
	printf("%d",num);

	//int aaa=10;
	//scanf("%d",&aaa);
	//printf("%d",aaa);
	
	return 0;

}
