#include <stdio.h>
#define LEN 4

int main( )   {

	int num;
	int a[LEN]= {0};
	printf("�п�J %d ���\n", LEN);
	scanf("%d", &num);

	if(num<1000 || num>=10000) {

		return -1;

	}

	int r;
	int newNum;
	for(int i=0; num!=0; ) {

		r=num%10;

		a[i++]=r;
		num/=10;// �k�� 1 ��

		//newNum = newNum*10 + r;

	}

	//printf("newNum=%d\n", newNum);

	for(int j=0; j<LEN; j++) {

		printf("a[%d]=%d\n",j, a[j]);

		newNum+=a[j];

		if(j!=(LEN-1)) {

			newNum*=10;

		}

	}

	printf("\naft inverse=%d\n", newNum);

}
