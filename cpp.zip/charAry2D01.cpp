#include <stdio.h>

int main( )   {

	char str[3][10]= {{"Tom"},{"Lily"},{"James Lee"}};

	for(int i=0; i<3; i++) {

		printf("str[%d]=%s\n", i, str[i]);

	}

	printf("\n");

	for(int i=0; i<3; i++) {

		printf("str[%d]=%p\n", i, str[i]);
		printf("addr str[%d][0]=%p\n\n", i, &str[i][0]);

	}

	return 0;

}
