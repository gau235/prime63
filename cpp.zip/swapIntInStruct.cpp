#include <iostream>

using namespace std;

struct data {

	string name;
	int a, b;

};

void show(struct data in) {

	cout<<"Name: "<<in.name <<endl;
	cout<<"a="<<in.a <<",";
	cout<<"b="<<in.b <<endl;

}

void swap2(struct data *ptr) {

	int temp=ptr->a;
	ptr->a=ptr->b;
	ptr->b=temp;

}

void swap3(struct data in) {

	int temp=in.a;
	in.a=in.b;
	in.b=temp;

}

int main( )   {

	struct data man= {
		"John",
		11,
		33
	};

	struct data lady= {
		"Linda",
		22,	
		44
	};

	cout<<"aft process..."<<endl;

	swap2(&man);
	swap3(lady);

	show(man);
	cout<<endl;
	show(lady);

	return 0;

}



