#include <stdio.h>
#define SIZE 12

void func2(int n) {

	int f[SIZE];
	f[0]=0;
	f[1]=1;
	f[2]=2;

	for  (int i = 3; i <= n; i++) {

		f[i] = f[i-1] + 2*f[i-2] - f[i-3];
		printf("f[%d]=%d\n", i, f[i]);

	}

}

void func(int n) {

	int ans,f2,f1,f0;
	f0=0;
	f1=1;
	f2=2;

	for  (int i = 3; i <= n; i++) {

		ans = f2 + 2*f1 - f0;
		printf("i=%d, ans=%d\n", i, ans);

		f0=f1;
		f1=f2;
		f2=ans;

	}

}


int main() {

	int num;
	int ans, ans2;

	printf("input a num:");

	scanf("%d", & num);
	printf("num=%d\n", num);

	func(num);

	return 0;

}
