#include <stdio.h>

void swap(int ary[]) {

	printf("\nin swap\n");

	printf("addr ary[0]=%X\n", &ary[0]);
	printf("addr ary[1]=%X\n", &ary[1]);

	int temp=ary[0];
	ary[0]=ary[1];
	ary[1]=temp;

}

int main( )   {

	int ary[]= {4,5};
	printf("bef swap\n" );
	printf("ary[0]=%d, ary[1]=%d\n", ary[0], ary[1]);

	printf("addr ary[0]=%X\n", &ary[0]);
	printf("addr ary[1]=%X\n", &ary[1]);

	swap(ary);

	printf("\naft swap\n");
	printf("ary[0]=%d, ary[1]=%d\n", ary[0], ary[1]);

	return 0;

}


