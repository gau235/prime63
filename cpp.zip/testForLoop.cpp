#include <stdio.h>

int main() {

	int y=0;
	for(int k=0; k<10; y+=k, printf("y=%d\n", y)) {

		if(++k==6) continue;

		k++;

	}

	return 0;

}


