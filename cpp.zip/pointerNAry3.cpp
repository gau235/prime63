#include <stdio.h>
#define SIZE 5

int* max(int*);

int main( )   {

	int a[5]= {3,1,7,2,6};
	int i, *ptr;

	for(i=0; i<SIZE; i++) {

		printf("a[%d]=%d\n", i, a[i]);// 4 bytes for an integer


	}

	ptr=max(a);

	printf("max=%d\n", *ptr);// 4 bytes for an integer

	return 0;

}

int* max(int* ary) {

	int* max=ary;
	int i;

	for(i=0; i<SIZE; i++) {

		if(*max < *(ary+i)) {

			max=ary+i;

		}

	}

	return max;

}
