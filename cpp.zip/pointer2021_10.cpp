#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void myFunc(int* a, int b, int* c, char* d) {

	c[1]= *a+b; // 3+3=6
	d[*c]= d[2]; // �� 3 �� char t
	
	b= 17;
	
	int* r= c+1;

	c= a;
	*c= *a+1;

	printf("myFunc r[0]= %d\n", r[0]);
	printf("myFunc= %s, %d, %d, %d, %d\n", &d[1], *a, b, *c, *r);

}

int main() {

	char animal[7]= "cat";
	int x= strlen(animal); // len=3
	int z[3]= {1,3,5};
	int* y= (int*)malloc(sizeof(int)*3);
	
	int* p= &x;
	int* q= &z[1];
	q[1]= *p+10;
	
	printf("q[0]= %d\n", q[0]);
	printf("q[1]= %d\n", q[1]);

	printf("bef= %s, %d, %d, %d, %d\n", animal, *z, z[1], z[2], x);

	myFunc(p, x, q, animal);
	
	printf("aft= %s, %d, %d, %d, %d\n", animal, z[0], z[1], z[2], x);

	return 0;

}




