#include <stdio.h>

int calcu1(int x, int* y) {

	x+=5;
	*y*=2;

	return *y+x;

}

int calcu2(int* x, int y) {

	*x+=5;
	y*=2;

	return *x+y;

}

int main( )   {

	int a=3, b=5;
	int ret1, ret2;

	ret1 = calcu1(a,&b) + calcu2(&a,b);
	ret2 = calcu2(&a,b) + calcu1(a,&b);


	printf("a=%d\n", a);
	printf("b=%d\n", b);
	printf("ret1=%d\n", ret1);
	printf("ret2=%d\n", ret2);

	return 0;

}


