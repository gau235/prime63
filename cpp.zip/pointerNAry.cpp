#include <stdio.h>

int main( )   {

	int i, a[2]= {32,16};

	printf("a=%d\n", a);
	printf("&a=%d\n", &a);
	printf("&a+1=%d\n", &a+1);

	for(i=0; i<2; i++) {

		printf("&a[%d]=%d\n", i, &a[i]);// 4 bytes for an integer
 
	}

	return 0;

}
