#include <stdio.h>

void replace(int*, int);
void func(int* ptr);

int main( )   {

	int a[] = { 13, 32, 67, 14, 95};

	int i;

	for(i=0; i<5; i++)
		printf("%d,", a[i]);

	replace(a, 24);

	printf("\n" );
	printf("aft replace\n" );

	for(i=0; i<5; i++)
		printf("%d,", a[i]);

	printf("\n", a[i]);

	//func(5,50);

}

void replace(int* ptr, int num) {

	*(ptr+3)=num;

}

void func(int a, int b) {
	int k=50;
}
