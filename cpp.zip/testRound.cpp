#include <stdio.h>


int round(double n) {

	if((n-(int)n) >=0.5 ) {

		return (int)n+1;

	}

	return (int)n;

}

int main() {

	double k = 4.885;

	printf("k=%.3f, round(k)=%d\n", k, round(k));

//int j=powN(10,3);

	return 0;


}


