#include <stdio.h>
#define LEN 5

void swap(int a[], int i, int j) {

	int temp = a[i];
	a[i] = a[j];
	a[j] = temp;

}

void reverse(int a[]) {

	int i, temp;
	for (i = 0; i < LEN/2; i++) {

		temp = a[i];
		a[i] = a[LEN - i - 1];
		a[LEN - i - 1] = temp;

	}

}

int main( )   {

	int a[] = { 1, 2, 3, 4, 5 };
	printf("bef reverse\n" );

	int i;
	for(i=0; i<LEN; i++)
		printf("a[%d%]=%d%\n", i, a[i]);

	reverse(a);

	printf("aft reverse\n" );
	for(i=0; i<LEN; i++)
		printf("a[%d%]=%d%\n", i, a[i]);


}
