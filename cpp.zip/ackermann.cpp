#include <stdio.h>

int ack(int m, int n) { //ack(3,3)=61

	while (m != 0) {

		if (n == 0) {

			n = 1;

		} else {

			n = ack(m, n - 1);

		}

		m--;

	}

	return n + 1;

}

int main()   {

	printf("input m n:");
	
	int m,n;
	scanf("%d%d", &m, &n);
	
	int ans = ack(m, n);

	printf("ans=%d\n", ans);

}
