#include <stdio.h>

int main() {

 

int a=1, b=2,c=3,d=4;

printf("%d\n %d\n %d\n %d\n",a+b+c+d,(b*=a),(a+=d),d++);
	
		int g = 4 > 2 ? 5 < 3 ? 3 : 5 : 7;

	printf("%d\n",g);
	
	return 0;
	
}


