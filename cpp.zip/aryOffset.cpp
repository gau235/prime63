using namespace std;
#include <stdio.h>
#include <iostream>

int main() {

 


	int ary[10][5];
	int* p1=&ary[5][0];
	int* p2=&ary[7][4];
	
	printf("p1 = %x\n", p1);
	printf("p2 = %x\n", p2);
	
	printf("p1 = %d\n", p1);
	printf("p2 = %d\n", p2);
	
	printf("(p2-p1) = %d\n", p2-p1);
	
	// cout<<(p2-p1)<<endl;
 
	return 0;
	
}


