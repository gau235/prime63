#include <stdio.h>

struct myF {
    
	int* name;
    
}F1[10];

int main() {

	printf("sizeof(F1) = %d\n", sizeof(F1));

	int* p;
	int* ary[10][9];
 
	printf("sizeof(p) = %d\n", sizeof(p));

	printf("sizeof(ary) = %d\n", sizeof(ary));

	printf("sizeof(int) = %d\n", sizeof(int));
	printf("sizeof(long) = %d\n", sizeof(long));
	printf("sizeof(long long) = %d\n", sizeof(long long));
	
	return 0;
	
}


