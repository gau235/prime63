#include <stdio.h>

void swap(int* a, int* b) {

// this do not work
//	int* temp=a;
//	a=b;
//	b=temp;

	int temp=*a;
	*a=*b;
	*b=temp;

}

int main( )   {

	int a=1, b=2, c=3;
	printf("bef swap\n" );
	printf("a=%d, b=%d, c=%d\n", a,b,c);

	swap(&a, &b);
	swap(&b, &c);

	printf("aft swap\n" );
	printf("a=%d, b=%d, c=%d\n", a,b,c);

	return 0;

}


