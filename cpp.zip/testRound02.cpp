#include <stdio.h>


int base10Pow(const int pow) {

	int ans=1;
	for(int i=1; i<=pow; i++) {

		ans=ans*10;

	}

	return ans;

}

double roundKeepNDigit(double num, int n) {

	int num2 = num;
	printf("num2=%f\n", num2);

	//int temp= (int)(num * base10Pow(n+1));
	int temp= num * base10Pow(n+1);// �۰��૬
	printf("temp=%d\n", temp);

	if(temp%10>=5) {

		temp=temp+10;

	}

	printf("temp=%d\n", temp);
	temp=temp/10;
	printf("temp=%d\n", temp);

	double ans=(double)temp;
	ans/=1.0;
	printf("ans=%f\n", ans);

	ans/=base10Pow(n);
	printf("ans=%f\n", ans);

	return ans;

}


int main() {

	double k = 1.6543;

	printf("k=%f, roundKeepNDigit(k)=%f\n", k, roundKeepNDigit(k, 1));
	printf("k=%f, roundKeepNDigit(k)=%f\n", k, roundKeepNDigit(k, 2));
	printf("k=%f, roundKeepNDigit(k)=%f\n", k, roundKeepNDigit(k, 3));

	return 0;
	
}


