#include <stdio.h>
#define ROW 3
#define COL 4

int main() {

	int i,j;
	double degr[3][4]= {{18.2, 17.3, 15.0, 13.4},
		{23.8, 25.1, 20.6, 17.8},
		{20.6, 21.5, 18.4, 15.7}
	};

	double max=degr[0][0];
	double min=degr[0][0];

	int maxIJ[2]= {0};
	int minIJ[2]= {0};

	for(i=0 ; i<ROW; i++) {

		for(j=0; j<COL; j++) {

			if(max < degr[i][j]) {

				maxIJ[0]=i;
				maxIJ[1]=j;
				max=degr[i][j];

			}
			
			if(min > degr[i][j]) {

				minIJ[0]=i;
				minIJ[1]=j;
				min=degr[i][j];

			}

		}

	}

	for(i=0; i<ROW; i++) {

		printf("�ɬq %d �b�g�@��g�|��Ť��O��:", i+1 );

		for(j=0; j<COL; j++) {

			printf("%.1f\t", degr[i][j]);

		}

		printf("\n");

	}
	
	printf("�ū׳̰� %.1f �b�ɬq %d �b�g %d \n", max, maxIJ[0]+1, maxIJ[1]+1);
	printf("�ū׳̧C %.1f �b�ɬq %d �b�g %d \n", min, minIJ[0]+1, minIJ[1]+1);
	
	return 0;

}
