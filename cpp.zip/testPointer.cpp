#include <stdio.h>

int main() {

	int m=20;
	int* p= &m;

	printf("m=%d\n", m);//20
	printf("&m=%x\n", &m);//23fe4c
	printf("*&m=%d\n", *&m);//20

	printf("\n");

	printf("*p=%d\n", *p);//20
	printf("p=%x\n", p);//23fe4c

	printf("&p=%x\n", &p);//23fe40

	printf("*&p=%x\n", *&p);//23fe4c
	printf("&*p=%x\n", &*p);//23fe4c

//	int m=50;
//	int* p;
//	p=&m;
//	p++;
//
//		printf("p=%x\n", *p);
//		printf("p=%x\n", *&p);
//		printf("p=%x\n", &p);

	return 0;

}


