#include <stdio.h>

void swap(int* a, int* b) {

// this do not work
//	int* temp=a;
//	a=b;
//	b=temp;

	int temp=*a;
	*a=*b;
	*b=temp;

}

int main( )   {

	int m=4, n=5;
	printf("bef swap\n" );
	printf("m=%d, n=%d\n", m,n);

	swap(&m, &n);

	printf("aft swap\n" );
	printf("m=%d, n=%d\n", m,n);

	return 0;

}


