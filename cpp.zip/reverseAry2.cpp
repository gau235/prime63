#include <stdio.h>
#define LEN 5


int main( )   {

	int a[] = { 1, 2, 3, 4, 5 };
	printf("bef reverse\n" );

	int i;
	for(i=0; i<LEN; i++)
		printf("a[%d%]=%d%\n", i, a[i]);


	int* p=&a[0], *q=&a[LEN-1];
	int temp;

	while(p<q) {

		temp=*p;

//(*p)++=*q;

		*p=*q;
		p++;
		//*p=*p+1;
		*q--=temp;

	}

	printf("aft reverse\n" );
	for(i=0; i<LEN; i++)
		printf("a[%d%]=%d%\n", i, a[i]);


}
