#include <stdio.h>
#include <cstring>
#include <iostream>

using namespace std;

int main() {

	//char cAry[80];// work with scanf
	char stack[80];
	//printf("infix:");
	//scanf("%s", cAry);//cmd consloe �s�� �K�W ((a+b)*(c-d))

	////////////////////////////////////////////////
	//string infix = "((a+b)-(c-d)*x)";
	string infix = "((a+b)-((c-d)*x))";
	printf("infix:%s\n", infix.c_str());// C �y���S�r�� 
		
	char cAry[80];//the more the better
	strcpy (cAry, infix.c_str());

	int len, i, k=0;
	len=strlen(cAry);

	for (i=0; i < len; i++) {

		if (cAry[i] >= 'a' && cAry[i] <= 'z') {

			printf("%c", cAry[i]);

		}

		if (cAry[i] == '*' || cAry[i] == '/') {

			stack[k++] = cAry[i];

		}

		if (cAry[i] == '+' || cAry[i] == '-') {

			stack[k++] = cAry[i];

		}

		if (cAry[i] == ')') {

			printf("%c", stack[--k]);// --k for stack

		}


	}



}
