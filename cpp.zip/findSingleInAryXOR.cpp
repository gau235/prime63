#include <stdio.h>
#define LEN 5

int main( )   {

	int ary[LEN] = {18, 28, 18, 45, 28};
	int ret=0;
	for (int i = 0; i < LEN; i++) {

		ret = ret ^ ary[i];

	}

	printf("ret=%d\n", ret);

}
