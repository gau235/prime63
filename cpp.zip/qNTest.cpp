#include <stdio.h>

int main( )   {

	int count=0;
	int inputAns[5];

	struct Test {

		char q[20];// ����D
		int stdAns;

	};

	Test theTest[5]= {
		{"Question1",1},
		{"Question2",2},
		{"Question3",3},
		{"Question4",4},
		{"Question5",5}

	};

	int i;
	for (i=0; i<5; i++) {

		printf("%s\n",theTest[i].q);
		scanf("%d", &inputAns[i]);

		if(inputAns[i]==theTest[i].stdAns) {

			count++;

		}

	}

	printf("���� %d �D, �o�� %d ��\n", count, count*20);

	return 0;

}
