#include <stdio.h>
#define LEN 6

int front=0;
int rear = 0;

char q[]= {};

void add(char c) {

	q[rear++]=c;

}

char del() {

	return q[front++];

}

int main() {

	add('A');
	add('B');
	add('C');
	del();
	del();
	add('D');

	/////////////////
	for(int i=front; i<rear; i++) {

		printf("q[%d]=%c\n",i, q[i]);

	}

	return 0;

}


