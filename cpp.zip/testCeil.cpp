#include <stdio.h>

int ceil(double n) {

	if(n==int(n)) {

		return n;

	}

	return int(n)+1;


}

int main() {

	double k=4.1;
	printf("k=%d\n", ceil(k));

	return 0;

}


