#include <stdio.h>

int main( )   {

	char* x[5]= {"BENZ","AUDI", "HONDA"};

	printf("%s\n", *(x+1));
	printf("%s\n", *(x+1)+1);

	printf("%c\n", **(x+1));// like as x[1][0]
	printf("%c\n", *(*(x+1)+1));

////////////////////////
	printf("%s\n", *x);
	printf("%s\n", x[0]);
	//printf("%s\n", x);

	printf("%p\n", x);
	printf("%p\n", &x);

	return 0;

}
