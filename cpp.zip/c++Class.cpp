#include <string>
using namespace std;

class Car {

	public:
		//static int num=10;//err
		static int num;
	  	int num2 = 20;

};

int Car::num=10;
 
int main() {

//Car ccc;
//int k=Car::num;
int k=Car::num;

	printf("k=%d\n", k);

}
