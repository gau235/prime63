#include <stdio.h>

int main( )   {

	int x[10]= {1,3,7,8,4,-1,7,6,-1,6};

	int y=0;
	while(x[y++]>0);
	printf("y=%d\n", y);

	y=0;
	while(x[++y/2]>0);
	printf("y=%d\n", y);


	return 0;

}
