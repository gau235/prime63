#include <stdio.h>


int main() {

	int inputMin;

	printf("input the parking minute:");

	scanf("%d", &inputMin);
	/////////////////

	int day=inputMin/1440;
	int hour=(inputMin%1440)/60;
	int min=inputMin%60;

	int costDay=day*200;
	int costHour=hour*30;
	int costMin = 0;

	if(min>=1 && min<=30) {

		costMin=20;

	}

	if(min>=31 && min<=59) {

		costMin=30;

	}

	int costHM = costHour + costMin;

	if(costHM > 200) {

		costHM = 200;

	}

	//////////////////

//	printf("costMin=%d\n", costMin);
	printf("cost=%d\n", costDay + costHM);

	return 0;

}
