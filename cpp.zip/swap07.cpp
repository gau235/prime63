#include <stdio.h>

void swap(int& a, int& b) {

	printf("\nin swap\n");

	printf("addr a=%X\n", &a);
	printf("addr b=%X\n", &b);

	int temp=a;
	a=b;
	b=temp;

}

int main( )   {

	int m=4, n=5;
	printf("bef swap\n" );
	printf("m=%d, n=%d\n", m,n);

	printf("addr m=%X\n", &m);
	printf("addr n=%X\n", &n);

	swap(m, n);

	printf("\naft swap\n");
	printf("m=%d, n=%d\n", m,n);

	return 0;

}


