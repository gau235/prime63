#include <stdio.h>

int main() {

  int i, j;

  for (i = 1; i <= 3; i++) {

    for (j = 1; i + j <= 3; j++) {
      printf(" ");
    }

    for (j = 1; j <= 2 * i - 1; j++) {
      printf("*");
    }

//    for (j = 1; i + j <= 3; j++) {
//      printf(" ");
//    }
    printf("\n");

  }
  
  //printf("ok");
  return 0;
}
