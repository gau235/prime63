#include <stdio.h>
#define ROW 3
#define COL 4

int main() {

	int i,j,k;
	double degr[3][4]= {{18.2, 17.3, 15.0, 13.4},
		{23.8, 25.1, 20.6, 17.8},
		{20.6, 21.5, 18.4, 15.7}
	};

	double avg[3]= {0.0};



	for(i=0 ; i<ROW; i++) {

		for(j=0; j<COL; j++) {

			avg[i]+=degr[i][j];

		}


	}

	for(k=0; k < 3; k++) {

		printf("�ɬq %d �����ū� %.1f\n",k+1 , avg[k]/4.0);

	}

	return 0;

}
