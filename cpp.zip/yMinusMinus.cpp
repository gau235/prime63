#include <stdio.h>

int main() {

	int x = 1;

		int y = 10;

		y /= ++x + y--;

		printf("y=%d", y);

}
