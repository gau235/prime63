allCoin=[50, 20, 20, 15, 10, 2, 1, 1, 1]
targetV=75

def giveChange(prefix, curIdx): # power set

	if (curIdx == len(allCoin) - 1): # Z 軸延伸

		tmpList=prefix.copy()
		tmpList.append(allCoin[curIdx])
		
		if(sum(tmpList)==targetV):
			print(tmpList)
		
		elif(sum(prefix)==targetV):
			print(prefix)
		
		return

	tmpList=prefix.copy()
	tmpList.append(allCoin[curIdx])
	
	giveChange(tmpList, curIdx+1)
	giveChange(prefix, curIdx+1)

# 以下是 main			 		
giveChange([],0)