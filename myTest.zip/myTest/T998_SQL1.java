package myTest;

/**
 * MySQL.<br/>
 * <br/>
 * MySQL.
 *
 * @version 2021/05/13_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/searchDocOfSrc.jsp?nameOfClass=T998_SQL1" >T998_SQL1.java</a>
 *
 */
class T998_SQL1 {

	public static void main(String[] sAry) {

//		INSERT INTO 客戶  VALUES (1, "甲乙科技","","");
//		INSERT INTO 客戶  VALUES (2, "大大科技","","");
//		INSERT INTO 業務員  VALUES (1, "王一","","");
//		INSERT INTO 業務員  VALUES (2, "王二","","");
//
//		INSERT INTO 訂單 VALUES (50, 1,1,"2020/01/01",5000);
//		INSERT INTO 訂單 VALUES (50, 2,1,"2020/01/01",4000); //大大科技

//		select 訂單.金額, 客戶.名稱  from 訂單 ,客戶
//		where  訂單.金額 >1000000
//
//		select 業務員.業務員編號, 業務員.姓名 from 業務員, 訂單 ,客戶
//		where 訂單.客戶編號=客戶.客戶編號
//		and 訂單.業務員編號=業務員.業務員編號
//		and 客戶.名稱='甲乙科技'

//		==========
//		UPDATE `訂單` SET 金額=1500000  WHERE 訂單編號=50

	}
}