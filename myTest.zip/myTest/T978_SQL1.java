package myTest;

/**
 * MySQL.<br/>
 * MySQL.
 *
 * @version 2021/05/13_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/searchDocOfSrc.jsp?nameOfClass=T978_SQL1" >T978_SQL1.java</a>
 *
 */
class T978_SQL1 {

	public static void main(String[] sAry) {

//		ALTER TABLE grade
//		ADD FOREIGN KEY (testerId) REFERENCES tester (testerId);

//		INSERT INTO grade(testerId, subjectId, gradeData, subject) VALUES (1,1,"A",'中文')
//
//		INSERT INTO tester (testerId, name) VALUES (1, "甲")
//		INSERT INTO tester (testerId, name) VALUES (6, "OscarLin")
//
//		INSERT INTO grade VALUES (6,1,"A",'中文');
//		INSERT INTO grade VALUES (6,2,"A",'英文');
//		INSERT INTO grade VALUES (6,3,"C",'數學');
//		INSERT INTO grade VALUES (6,4,"B",'自然');
//		INSERT INTO grade VALUES (6,5,"A",'社會');
		// ========================

		// SELECT subject, gradedata, count(*)
		// FROM grade
		// group by subject, gradedata

//		====================
//		select tester.testerId, grade.testerId, name, gradeData from tester,grade
//		where tester.testerId=grade.testerId
//		and subject="中文" and gradeData="A"
//
//		==========
//		DELETE FROM `tester` WHERE name="A"

	}
}